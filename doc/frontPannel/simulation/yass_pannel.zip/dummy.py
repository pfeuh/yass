#!/usr/bin/python
# -*- coding: utf-8 -*-

for x in range(32):
    print("%2u, %3u"%(x + 1, 80 + x * 5))
    
    
    
    
    
    
    